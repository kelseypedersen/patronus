// DB connection

var mysql = require('mysql');
var dbConfig = require('./database.json');

var connection = mysql.createConnection({
  host     : dbConfig.production.host,
  user     : dbConfig.production.user,
  password : dbConfig.production.password,
  database : dbConfig.production.database
});

connection.connect();


// Handle someone submitting ?op=METHOD etc


module.exports = exports = Object.create(null);


// Sample URLs:
// patronus-team.herokuapp.com/survivor?op=createNewSurvivor  => returns ID
// patronus-team.herokuapp.com/survivor?op=createNewSurvivor&survivor_phone_number=12345  => returns ID

exports['createNewSurvivor'] = function (req, res, next) {

  var query_params;

  connection.beginTransaction(function(err) {
    if (err) { throw err; }

    query_params = {survivor_phone_number: req.param('survivor_phone_number')};

    connection.query('DELETE FROM Survivors WHERE ?', query_params, function(err, result) {
      if (err) {
        return connection.rollback(function() {
          throw err;
        });
      }

      connection.query('INSERT INTO Survivors SET ?', query_params, function(err, result) {
        if (err) {
          return connection.rollback(function() {
            throw err;
          });
        }

        console.log('Survivor ID ' + result.insertId + ' added!');

        connection.commit(function(err) {
          if (err) {
            return connection.rollback(function() {
              throw err;
            });
          }
          console.log('SUCCESS!');

          res.render('index', { title: 'createNewSurvivor Done with ID ' + result.insertId });

        });
      });
    });
  });


};


// patronus-team.herokuapp.com/survivor?op=addSurvivorName&id=[survivor_id]&name=MY_NAME_IS


exports['addSurvivorName'] = function (req, res, next) {

  var id = req.param('id');

  query_params = {id: req.param('id'), name: connection.escape(req.param('name'))};

  connection.query('UPDATE Survivors SET name="' + query_params.name +'" WHERE id=' + query_params.id, function (err, result) {
    if (err) throw err;

    console.log('changed ' + result.changedRows + ' rows');
    res.render('index', { title: 'addSurvivorName Done for ID '+ id });

  });

};


// TODO: Fix authentication

// patronus-team.herokuapp.com/json?op=listSurvivors


exports['listSurvivors'] = function (req, res, next) {

  var id = req.param('id');

  connection.query('SELECT * FROM Survivors', function (err, rows, fields) {
    if (err) throw err;
    res.send({length: rows.length, rows: rows});

  });

};


// patronus-team.herokuapp.com/json?op=listSupporters&survivor_id=1


exports['listSupporters'] = function (req, res, next) {

  query_params = {survivor_id: req.param('survivor_id')};

  connection.query('SELECT * FROM Supporters WHERE ?', query_params, function (err, rows, fields) {
    if (err) throw err;
    res.send({length: rows.length, rows: rows});

  });

};


// patronus-team.herokuapp.com/json?op=listIncidents
// patronus-team.herokuapp.com/json?op=listIncidents&survivor_id=1

exports['listIncidents'] = function (req, res, next) {

  query_params = {survivor_id: req.param('survivor_id')};

  if (query_params.survivor_id) {

    connection.query('SELECT * FROM Incidents WHERE ?', query_params, function (err, rows, fields) {
      if (err) throw err;
      res.send({length: rows.length, rows: rows});

    });

  } else {

    connection.query('SELECT * FROM Incidents', function (err, rows, fields) {
      if (err) throw err;
      res.send({length: rows.length, rows: rows});

    });

  }

};



// patronus-team.herokuapp.com/map


exports['map'] = function (req, res, next) {

  // all incidents
  connection.query('SELECT location_latitude, location_longitude FROM Incidents WHERE location_latitude IS NOT NULL and location_longitude IS NOT NULL', function (err, rows, fields) {
    if (err) throw err;
    
    var arr = [];


    var util = require('util');
    console.log("rows: ", util.inspect(rows));

    for(var i = 0; i < rows.length; i++) {
      arr.push([rows[i].location_latitude, rows[i].location_longitude]);
    }

    res.render('map', { addressPointsArray: arr });

  });



};



