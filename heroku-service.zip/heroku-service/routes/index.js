var express = require('express');
var router = express.Router();

// https://codeforgeek.com/2014/09/handle-get-post-request-express-4/

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

// Main Operations Router
var ops = require('../ops');
var op_name;

router.get('/survivor', function(req, res, next) {

  //var util = require('util');
  //console.log("ops: ", util.inspect());
  //param: https://scotch.io/tutorials/use-expressjs-to-get-url-and-post-parameters

  op_name = req.param('op');
  ops[op_name](req, res, next);

});


router.get('/json', function(req, res, next) {

  op_name = req.param('op');
  ops[op_name](req, res, next);

});


router.get('/map', function(req, res, next) {

  ops["map"](req, res, next);

});

module.exports = router;
