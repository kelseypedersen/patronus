var dbm = global.dbm || require('db-migrate');
var type = dbm.dataType;

/* sample commands

./node_modules/.bin/db-migrate create createSurvivor --env production


./node_modules/.bin/db-migrate up --env production
./node_modules/.bin/db-migrate down --env production

*/



exports.up = function(db, callback) {
  async.series(
    [

      db.createTable.bind(db, 'Survivors', {
        id: { type: 'int', primaryKey: true, autoIncrement: true, notNull: true },
        name: { type: 'string', length: '256', notNull: false, unique: false },
        street_address: { type: 'string', length: '512', notNull: false, unique: false },
        zip_code: { type: 'string', length: '128', notNull: false, unique: false },
        survivor_phone_number: { type: 'string', length: '256', notNull: false, unique: false },
        attacker_phone_number: { type: 'string', length: '256', notNull: false, unique: false },
        check_in: { type: 'int', notNull: false, defaultValue: 0 }
      }),


      db.createTable.bind(db, 'Incidents', {
        id: { type: 'int', primaryKey: true, autoIncrement: true, notNull: true },
        survivor_id: { type: 'int', notNull: false,
			foreignKey: {name: 'incident_survivor_id_foreign_key', table: 'Survivors', rules: { onDelete: 'SET NULL', onUpdate: 'CASCADE'}, mapping: 'id' }},
        text_message_body: { type: 'string', length: '1600', notNull: true, unique: false },
        location_latitude: { type: 'float', notNull: false, unique: false},
        location_longitude: { type: 'float)', notNull: false, unique: false},
        date_time: { type: 'datetime', notNull: true, unique: false }
      }),

      // actions: call supporters, trigger interruption call (call attacker), multiple_action (e.g. both)
      db.createTable.bind(db, 'Actions', {
        id: { type: 'int', primaryKey: true, autoIncrement: true, notNull: true },
        action_name: { type: 'string', length: '128', notNull: true, unique: true }
      }),

      db.createTable.bind(db, 'Survivor_Actions', {
        id: { type: 'int', primaryKey: true, autoIncrement: true, notNull: true },
        survivor_id: { type: 'int', notNull: true, unique: false },
        action_id: { type: 'int', notNull: true, unique: false }
      }),

      db.createTable.bind(db, 'Supporters', {
        id: { type: 'int', primaryKey: true, autoIncrement: true, notNull: true },
        survivor_id: { type: 'int', notNull: true, unique: false },
        name: { type: 'string', length: '256', notNull: false, unique: false },
        phone_number: { type: 'string', length: '256', notNull: false, unique: false },
      }),


      // seed tables w data
      // *******************************************

      db.insert.bind(db, 'Actions', ['id', 'action_name'],[1, 'CALL_SUPPORTERS']),
      db.insert.bind(db, 'Actions', ['id', 'action_name'],[2, 'INTERRUPT_ATTACKER']),
      db.insert.bind(db, 'Actions', ['id', 'action_name'],[3, 'CHIME']),


      db.insert.bind(db, 'Survivor_Actions', ['survivor_id', 'action_id'], [1, 1]),
      db.insert.bind(db, 'Survivor_Actions', ['survivor_id', 'action_id'], [1, 2]),
      db.insert.bind(db, 'Survivor_Actions', ['survivor_id', 'action_id'], [1, 3]),

    ], callback);
};

exports.down = function(db, callback) {
  async.series(
    [
      db.dropTable.bind(db, 'Incidents'),
      db.dropTable.bind(db, 'Actions'),
      db.dropTable.bind(db, 'Supporters'),
      db.dropTable.bind(db, 'Survivors'),
      db.dropTable.bind(db, 'Survivor_Actions'),
    ], callback);
};
