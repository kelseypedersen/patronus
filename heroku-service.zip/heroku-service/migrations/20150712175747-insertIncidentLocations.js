var dbm = global.dbm || require('db-migrate');
var type = dbm.dataType;


// ./node_modules/.bin/db-migrate down --env production --count 1

/* populate date time

Update Incidents set date_time = 
FROM_UNIXTIME( UNIX_TIMESTAMP('2013-07-01 14:53:27') + FLOOR(0 + (RAND() * 63072000)) ) 
WHERE date_time is null;

*/


exports.up = function(db, callback) {

  async.series(
    [

   db.insert.bind(db, 'Incidents', ['survivor_id', 'text_message_body', 'location_latitude', 'location_longitude'],
        [1, 'Test Incident via Node', 37.7833,-122.4167]),

   db.insert.bind(db, 'Incidents', ['survivor_id', 'text_message_body', 'location_latitude', 'location_longitude'],
        [1, 'Test Incident via Node', 37.7843,-122.4177]),

   db.insert.bind(db, 'Incidents', ['survivor_id', 'text_message_body', 'location_latitude', 'location_longitude'],
        [1, 'Test Incident via Node', 37.7853,-122.4187]),

   db.insert.bind(db, 'Incidents', ['survivor_id', 'text_message_body', 'location_latitude', 'location_longitude'],
        [1, 'Test Incident via Node', 37.7832,-122.4197]),

   db.insert.bind(db, 'Incidents', ['survivor_id', 'text_message_body', 'location_latitude', 'location_longitude'],
        [1, 'Test Incident via Node', 37.7863,-122.4867]),

   db.insert.bind(db, 'Incidents', ['survivor_id', 'text_message_body', 'location_latitude', 'location_longitude'],
        [1, 'Test Incident via Node', 37.7838,-122.4117]),

   db.insert.bind(db, 'Incidents', ['survivor_id', 'text_message_body', 'location_latitude', 'location_longitude'],
        [1, 'Test Incident via Node', 37.7833,-122.4362]),

   db.insert.bind(db, 'Incidents', ['survivor_id', 'text_message_body', 'location_latitude', 'location_longitude'],
        [1, 'Test Incident via Node', 37.7803,-122.4462]),

   db.insert.bind(db, 'Incidents', ['survivor_id', 'text_message_body', 'location_latitude', 'location_longitude'],
        [1, 'Test Incident via Node', 37.7831,-122.4352]),

   db.insert.bind(db, 'Incidents', ['survivor_id', 'text_message_body', 'location_latitude', 'location_longitude'],
        [1, 'Test Incident via Node', 37.7832,-122.4556]),

   db.insert.bind(db, 'Incidents', ['survivor_id', 'text_message_body', 'location_latitude', 'location_longitude'],
        [1, 'Test Incident via Node', 37.7853,-122.4492]),

   db.insert.bind(db, 'Incidents', ['survivor_id', 'text_message_body', 'location_latitude', 'location_longitude'],
        [1, 'Test Incident via Node', 37.5833,-122.3362]),

    ], callback);

};

exports.down = function(db, callback) {
    db.runSql(
        'DELETE FROM Incidents WHERE text_message_body="Test Incident via Node"', [], callback);
};
